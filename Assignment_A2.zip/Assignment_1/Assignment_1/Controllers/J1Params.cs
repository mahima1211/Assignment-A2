﻿
namespace Assignment_1.Controllers
{
    public class J1Params
    {

        public int burger { get; set; }
        public int drink { get; set; }
        public int side { get; set; }
        public int dessert { get; set; }
    }
}
