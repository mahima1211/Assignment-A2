﻿namespace Assignment_1.Controllers
{
    public class dice
    {
        public int m { get; set; }
        public int n { get; set; }
    }
}
