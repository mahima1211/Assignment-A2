﻿using Assignment_1.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace Assignment_1.Controllers
{
   /* [Route("/api/J1/Menu")]*/
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }
        [HttpGet("/api/J1/Menu/{burger}/{drink}/{side}/{dessert}", Name = nameof(Index))]
        public IActionResult Index(J1Params param)
        {
            int burger = int.Parse(param.burger+"");
            int drink = int.Parse(param.drink + "");
            int side = int.Parse(param.side + "");
            int dessert = int.Parse(param.dessert + "");
            int total = 0;
            switch (burger)
            {
                case 1:
                    total = total + 461;
                    break;
                case 2:
                    total = total + 431;
                    break;
                case 3:
                    total = total + 420;
                    break;
                case 4:
                    total = total + 0;
                    break;
            }
            switch (drink)
            {
                case 1:
                    total = total + 130;
                    break;
                case 2:
                    total = total + 160;
                    break;
                case 3:
                    total = total + 118;
                    break;
                case 4:
                    total = total + 0;
                    break;
            }
            switch (side)
            {
                case 1:
                    total = total + 100;
                    break;
                case 2:
                    total = total + 57;
                    break;
                case 3:
                    total = total + 70;
                    break;
                case 4:
                    total = total + 0;
                    break;
            }
            switch (dessert)
            {
                case 1:
                    total = total + 167;
                    break;
                case 2:
                    total = total + 266;
                    break;
                case 3:
                    total = total + 75;
                    break;
                case 4:
                    total = total + 0;
                    break;
            }
            ViewBag.Message = "Your total calorie count is :" + total;
            return View();
        }

        [HttpGet("/api/J2/DiceGame/{m}/{n}", Name = nameof(Privacy))]
        public IActionResult Privacy(dice obj)
        {
            int m = obj.m;
            int n = obj.n;
            int start = n;
            int end = m;
            int total = 0;
            if (m<n)
            {
                start = m;
            }
            if (m < n)
            {
                end = n;
            }
            for (int i=1;i<=start;i++)
            {
                if (10-i<=end)
                {
                    total++;
                }
            }
            ViewBag.Message = "There are "+total +" ways to get the sum 10.";
;
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}